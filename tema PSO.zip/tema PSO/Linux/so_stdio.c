#include "so_stdio.h"
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>
#include <stdio.h>

SO_FILE *so_fopen(const char *pathname, const char *mode)
{
	SO_FILE *file;
	int aux = 0;
	int fd = -1;

	if (strcmp(mode, "a") == 0) {
		fd = open(pathname, O_WRONLY | O_APPEND | O_CREAT, 0666);
		aux = 1;
	}
	if (strcmp(mode, "a+") == 0) {
		fd = open(pathname, O_RDWR | O_APPEND | O_CREAT, 0666);
		aux = 1;
	}
	if (strcmp(mode, "r") == 0) {
		fd = open(pathname, O_RDONLY);
		aux = 1;
	}
	if (strcmp(mode, "r+") == 0) {
		fd = open(pathname, O_RDWR);
		aux = 1;
	}
	if (strcmp(mode, "w") == 0) {
		fd = open(pathname, O_WRONLY | O_CREAT | O_TRUNC, 0666);
		aux = 1;
	}
	if (strcmp(mode, "w+") == 0) {
		fd = open(pathname, O_RDWR | O_CREAT | O_TRUNC, 0666);
		aux = 1;
	}
	if (aux == 0 || fd == -1)
		return NULL;
	file = calloc(1, sizeof(SO_FILE));
	file->next = file->buffer;
	file->mode1 = 0;
	file->fd = fd;
	file->pos = 0;
	file->count = 0;
	return file;
}

int so_fclose(SO_FILE *stream)
{
	int flush = so_fflush(stream);

	if (close(stream->fd) > 0) {
		free(stream);
		return flush;
	}
	else {
		free(stream);
		return SO_EOF;
	}
}

int so_fileno(SO_FILE *stream)
{
	return stream->fd;
}

int so_fflush(SO_FILE *stream)
{
	int mode = stream->mode1;
	int to_return;

	if (stream->mode1 == 2) {
		to_return =
			write(stream->fd, stream->buffer, stream->count);
		if (to_return >= 0)
			stream->mode1 = 0;
		else
			stream->mode1 = 4;
	}
	stream->count = 0;
	stream->next = stream->buffer;
	if (stream->mode1 == 4 && mode != 4)
		return SO_EOF;
	return 0;
}

int so_fseek(SO_FILE *stream, long offset, int whence)
{
	stream->pos = lseek(stream->fd, offset, whence);
	if (stream->pos < 0)
		return -1;
	return 0;
}

long so_ftell(SO_FILE *stream)
{
	return stream->pos;
}

size_t so_fread(void *ptr, size_t size, size_t nmemb, SO_FILE *stream)
{
	int aux = nmemb;
	int val = nmemb * size;
	if (stream->mode1 == 4 || stream->mode1 == 3)
		return 0;
	while (val > 0) {
		int s = so_fgetc(stream);

		if (stream->mode1 == 4)
			return 0;
		if (stream->mode1 == 3)
			return aux - nmemb;
		aux--;
		*(char *)ptr = (char)s;
		ptr++;
	}
	return aux;
}

size_t so_fwrite(const void *ptr, size_t size, size_t nmemb, SO_FILE *stream)
{
	int aux = nmemb;
	int val = nmemb * size;
	if (stream->mode1 > 3)
		return 0;
	while (val > 0) {
		so_fputc((int)*(char *)ptr++, stream);
		if (stream->mode1 == 4)
			return aux - nmemb;

		val--;
	}
	return aux;
}

int so_fgetc(SO_FILE *stream)
{
	int ret_val;

	if (stream->mode1 != 1) {
		if (stream->mode1 == 2) {
			write(stream->fd, stream->buffer, max);
		}

		stream->mode1 = 1;
		stream->count = 0;
		stream->next = stream->buffer;
	}
	if (stream->count == 0) {
		stream->count = read(stream->fd, stream->buffer, max);
		stream->next = stream->buffer;
		if (stream->count < 0) {
			stream->mode1 = 4;
			return SO_EOF;
		}
		if (stream->count == 0) {
			stream->mode1 = 3;
			return SO_EOF;
		}

	}
	stream->pos++;
	stream->count--;
	ret_val = (int)(*(stream->next));
	//if (stream->count != 0)
	//      stream->next++;
	//else
	//      stream->next = stream->buffer;
	//stream->count == 0 ? stream->next =
	//    stream->buffer : stream->next++;
	stream->next++;
	return (int)ret_val;
}

int so_fputc(int c, SO_FILE *stream)
{
	int to_return = 0;

	if (stream->mode1 != 2) {
		stream->count = 0;
		stream->next = stream->buffer;
		stream->mode1 = 2;
	}
	if (stream->count != max) {
		stream->count++;
		stream->pos++;
		*stream->next = (char)c;
		if (stream->count == max) {
			stream->next = stream->buffer;
		}
		else {
			stream->next++;
		}
	}
	else {
		to_return = write(stream->fd, stream->buffer, max);
		if (to_return < 0) {
			stream->mode1 = 4;
			return -1;
		}
		stream->count = 0;
		stream->count++;
		stream->pos++;
		*stream->next = (char)c;
		if (stream->count == max) {
			stream->next = stream->buffer;
		}
		else {
			stream->next++;
		}
	}
	return c;
}

int so_feof(SO_FILE *stream)
{
	if (stream->mode1 == 3)
		return 3;
	return 0;
}

int so_ferror(SO_FILE *stream)
{
	if (stream->mode1 == 4)
		return 4;
	return 0;
}

SO_FILE *so_popen(const char *command, const char *type)
{
	return NULL;
}

int so_pclose(SO_FILE *stream)
{
	int stat;
	pid_t pid;

	pid = stream->pid;
	(void)so_fclose(stream);
	while (waitpid(pid, &stat, 0) == -1) {
		if (errno != EINTR) {
			stat = -1;
			break;
		}
	}
	return(stat);
}

int main()
{



}