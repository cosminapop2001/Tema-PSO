Nume: Pop Daria Cosmina
Grupă: C113D

Tema 1 - Biblioteca STDIO 

Utilitate tema:
Tema mi se pare foarte utila si interesanta deoarece m-a familiarizat cu apelurile de sistem . Am invatat multe lucruri si am folosit
mare parte din informatiile de la laborator.

Consider ca am implementat destul de binisor fiecare functie.
Nu prea mi-au iesit testele pe checker, cel mai probabil nu am luat in considerare anumite exceptii.Am incercat sa verific toate cazurile, in mare.

Implementare:
Intregul enunt al temei este implementat,in afara de functiile
popen/pclose pe Windows (am dat direct return NULL/0).


Compilare+Rulare:
Se linkeaza bibliotecile specificate in enuntul temei.
Compilare:
Linux:
    make -f Makefile
    
Windows:
    nmake -f Makefile
    .\tema1.exe file1 file2 ...


Bibliografie:
1.Laboratoare PSO
2.stdio.h functions - http://www.cplusplus.com/reference/cstdio/
3.http://man7.org/linux/man-pages