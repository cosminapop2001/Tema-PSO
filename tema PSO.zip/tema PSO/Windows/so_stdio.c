#include "so_stdio.h"
#include <windows.h>


/*Internal functions*/

DWORD getDesiredAccess(const char* identifier){
	if(!strcmp(identifier,"a")) return FILE_APPEND_DATA | GENERIC_READ;
	else if (!strcmp(identifier,"r")) return GENERIC_READ;
    else if (!strcmp(identifier,"w")) return GENERIC_WRITE;
	else if (!strcmp(identifier,"a+")) return FILE_APPEND_DATA | GENERIC_READ;
	else if (!strcmp(identifier,"w+")) return GENERIC_READ | GENERIC_WRITE;
	else if (!strcmp(identifier,"r+")) return  GENERIC_READ | GENERIC_WRITE;
	
	
}

DWORD getShareMode(const char* identifier){
	if(!strcmp(identifier,"a")) return FILE_APPEND_DATA | GENERIC_READ;
	else if (!strcmp(identifier,"r")) return FILE_SHARE_READ | FILE_SHARE_WRITE;
	else if (!strcmp(identifier,"w")) return FILE_SHARE_READ | FILE_SHARE_WRITE;
	else if (!strcmp(identifier,"a+")) return FILE_SHARE_WRITE;
	else if (!strcmp(identifier,"w+")) return  FILE_SHARE_READ | FILE_SHARE_WRITE;
	else if (!strcmp(identifier,"r+")) return FILE_SHARE_READ | FILE_SHARE_WRITE;
	
}

DWORD getCreationDisposition(const char* identifier){
	if(!strcmp(identifier,"a")) return OPEN_ALWAYS;
	else if (!strcmp(identifier,"r")) return OPEN_EXISTING;
	else if (!strcmp(identifier,"w")) return CREATE_ALWAYS;
	else if (!strcmp(identifier,"a+")) return OPEN_ALWAYS;
	else if (!strcmp(identifier,"w+")) return  CREATE_ALWAYS;
	else if (!strcmp(identifier,"r+")) return OPEN_EXISTING;
}

DWORD getFlagsAndAttributes(const char* identifier){
	if(!strcmp(identifier,"a")) return FILE_ATTRIBUTE_NORMAL;
	else if (!strcmp(identifier,"r")) return FILE_ATTRIBUTE_NORMAL;
	else if (!strcmp(identifier,"w")) return FILE_ATTRIBUTE_NORMAL;
	else if (!strcmp(identifier,"a+")) return FILE_ATTRIBUTE_NORMAL;
	else if (!strcmp(identifier,"w+")) return  FILE_ATTRIBUTE_NORMAL;
	else if (!strcmp(identifier,"r+")) return FILE_ATTRIBUTE_NORMAL;
}

/******************/

SO_FILE *so_fopen(const char *pathname, const char *mode)
{
    SO_FILE *f;
    HANDLE fd = -1;

    if(strcmp(mode, "a") && strcmp(mode, "r") && strcmp(mode, "w") &&
        strcmp(mode, "a+") && strcmp(mode, "r+") && strcmp(mode, "w+")) {
            return NULL;
        }

	fd = CreateFile(pathname, getDesiredAccess(mode), getShareMode(mode), NULL, getCreationDisposition(mode), getFlagsAndAttributes, NULL);
	

    if (fd == INVALID_HANDLE_VALUE) {
        return NULL;
    }
	
    f = calloc(1, sizeof(SO_FILE));
    f->buff_base = calloc(4096, sizeof(char));
    if (f->buff_base == NULL)
        return NULL;             // aici rezolva asta -- ceva perror
    f->next = f->buff_base;
    f->fd = fd;
    f->mode = _NONE;  // vezi aici
    f->count = 0;
    f->cursor = 0;

    return f;
}

int so_fclose(SO_FILE *stream) {
    BOOL cR = CloseHandle(stream->fd);
	
	int res = so_fflush(stream);
	
	free(stream->buff_base);
    free(stream);
    
	return cR == FALSE ? SO_EOF : res;
}

HANDLE so_fileno(SO_FILE *stream) {
	return stream->fd;
}

int so_fflush(SO_FILE *stream) {
    int aux = stream->mode;
    int bW = 0;
    if (stream->mode == _WRITE) {
        BOOL x = WriteFile(stream->fd, stream->buff_base, stream->count, &bW, NULL);
        
		stream->mode = !x ? _ERR : _NONE;
    }

    stream->next = stream->buff_base;
    stream->count = 0;

    if (aux != _ERR && so_ferror(stream)) {
        return SO_EOF;
    }

    return 0;
}

int so_fseek(SO_FILE *stream, long offset, int whence) {
    DWORD bty;
    if (stream->mode == _WRITE) {
        so_fflush(stream);
    } else if (stream->mode == _READ) {
        stream->next = stream->buff_base;
        stream->count = 0;
    }

    bty = SetFilePointer(stream->fd, offset, NULL, whence);

    stream->cursor = bty;

	return bty < 0 ? -1 : 0;
}

long so_ftell(SO_FILE *stream) {
    return stream->cursor;
}

size_t so_fread(void *ptr, size_t size, size_t nmemb, SO_FILE *stream) {
    DWORD r;
    if (so_feof(stream) || so_ferror(stream))
       return 0;
   r = nmemb;

   while (nmemb > 0) {
       int res = so_fgetc(stream);
       if (so_feof(stream))
           return r - nmemb;
       if (so_ferror(stream))
           return 0;
       nmemb--;
       *(CHAR *)ptr = (CHAR) res;
       ptr = ((char *) ptr) + 1;
   }

   return r;
}

size_t so_fwrite(const void *ptr, size_t size, size_t nmemb, SO_FILE *stream) {
    DWORD t;
    if (so_ferror(stream))
        return 0;
    t = nmemb;

    while (nmemb > 0) {
        so_fputc((int)*(char *)ptr, stream);
        ptr = ((char *) ptr) + 1;
        if (so_ferror(stream))
            return t - nmemb;
        nmemb--;
    }

    return t;
}

void changeMode(SO_FILE *stream, int mode)
{
	if(mode != _WRITE && mode != _READ) return;
	
    if (mode == _WRITE) {   
           stream->mode = _WRITE;
    }
	else if (mode == _READ) {
	   int bytesWritten = 0;
       if (stream->mode == _WRITE) {
           WriteFile(stream->fd, stream->buff_base, stream->count, &bytesWritten, NULL);
       }
	   stream->mode = _READ;
   }
   
   stream->count = 0;
   stream->next = stream->buff_base;
}

int so_fgetc(SO_FILE *stream) {
    
	changeMode(stream, _READ);
    if (stream->count == 0) {
        BOOL valoare = ReadFile(stream->fd, stream->buff_base, 4096, &(stream->count), NULL);
        stream->mode = !valoare ? _ERR 
							: (stream->count == 0) ? _EOF : stream->mode;
		 
        if(stream->count <= 0)
            return SO_EOF;
    }

    stream->cursor++;
    stream->count--;
    
	stream->next = stream->count == 0 ? stream->buff_base : stream->next++;
	
    return (int) *(stream->next);
}

int so_fputc(int c, SO_FILE *stream) {
    int returnamVals;
    changeMode(stream, _WRITE);
    if (stream->count == 4096) {
        BOOL x = WriteFile(stream->fd, stream->buff_base, 4096, &returnamVals, NULL);
        if(!x) {
            stream->mode = _ERR;
            return SO_EOF;
        }
        stream->count = 0;
    }

    stream->count++;
    stream->cursor++;
    *stream->next = (char)c;
    
	stream->next = stream->count == 4096 ? stream->buff_base : stream->next++;

    return c;
}

int so_feof(SO_FILE *stream) {
    if (stream->mode == _EOF) {
        return _EOF;
    }

    return 0;
}

int so_ferror(SO_FILE *stream) {
    if (stream->mode == _ERR) {
        return _ERR;
    }

    return 0;
}

SO_FILE *so_popen(const char *command, const char *type) {
   return  NULL;
}

int so_pclose(SO_FILE *stream) {
	return 0;
}
